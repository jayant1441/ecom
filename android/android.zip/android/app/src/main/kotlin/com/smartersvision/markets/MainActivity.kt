package com.smartersvision.markets

import io.flutter.embedding.android.FlutterActivity;

class MainActivity: FlutterActivity() {
}
